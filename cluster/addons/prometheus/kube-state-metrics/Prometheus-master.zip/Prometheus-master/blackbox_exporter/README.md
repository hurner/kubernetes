### Blackbox Exporter 0.14 for Prometheus 监控展示看板
>目前在使用的TCP，ICMP，HTTPS服务状态监控 Prometheus Blackbox Exporter，在一个看板里面展示，做了展示效果的优化，支持多服务同时展示，需要使用的可以参考下，记得根据自己的实际情况修改下变量。

https://grafana.com/grafana/dashboards/9965
### 记得安装饼图插件
![](https://github.com/starsliao/Prometheus/raw/master/blackbox_exporter/blackbox-exporter.png)
