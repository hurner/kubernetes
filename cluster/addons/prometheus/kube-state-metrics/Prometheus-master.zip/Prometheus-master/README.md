# Prometheus
### [1 Kubernetes for Prometheus Dashboard](https://github.com/starsliao/Prometheus/tree/master/kubernetes)
### [2 Node Exporter for Prometheus Dashboard](https://github.com/starsliao/Prometheus/tree/master/node_exporter)
### [3 Blackbox Exporter 0.14 for Prometheus Dashboard](https://github.com/starsliao/Prometheus/tree/master/blackbox_exporter)
### [4 windows_exporter for Prometheus Dashboard](https://github.com/starsliao/Prometheus/tree/master/windows_exporter)

#### 请进入相应目录查看说明与截图

### 关注公众号【**全栈运维开发**】加入运维群交流，获取更多...
![](https://github.com/starsliao/Prometheus/blob/master/qr.jpg)
