### Grafana v6.7.4/v7.2.0 +  node_exporter 1.0.1
### The dashboard is quite practical, to optimize the main metrics for display, and supporting Node Exporter v0.16 and above.Includes: CPU,memory,disk I/O, network traffic, temperature and other monitoring metrics.

### 中文版：[https://grafana.com/grafana/dashboards/8919](https://grafana.com/grafana/dashboards/8919)
### English Version：[https://grafana.com/grafana/dashboards/11074](https://grafana.com/grafana/dashboards/11074)

### 关注公众号【**全栈运维开发**】加入运维群交流，获取更多...
![](https://github.com/starsliao/Prometheus/blob/master/qr.jpg)

##### 截图
![](https://github.com/starsliao/Prometheus/blob/master/node_exporter/sa.png)
![](https://github.com/starsliao/Prometheus/blob/master/node_exporter/s1.png)
