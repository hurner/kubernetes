###  Grafana v6.7.X/v7.1.X + windows_exporter 0.13.0测试通过
#### Windows的Prometheus监控看板展示，增加了资源汇总展示，优化了明细展示。更新支持windows_exporter 0.13.0。
### 中文版：[https://grafana.com/grafana/dashboards/10467](https://grafana.com/grafana/dashboards/10467)


#### 截图

![](https://github.com/starsliao/Prometheus/blob/master/windows_exporter/windows_exporter.png)  
### 运维博客：[StarsL.cn](https://starsl.cn/)
### GitHub：[https://github.com/starsliao/Prometheus](https://github.com/starsliao/Prometheus)
### windows_exporter：[https://github.com/prometheus-community/windows_exporter](https://github.com/prometheus-community/windows_exporter)

#### 关注公众号【**全栈运维开发 Python & Vue**】获取更多...
![](https://github.com/starsliao/Prometheus/blob/master/qr.jpg)
